
  # Corporate Environmental Consultancy Landing Page

  This is a code bundle for Corporate Environmental Consultancy Landing Page. The original project is available at https://www.figma.com/design/9QE6rsmSbm2UhIvha9hUmG/Corporate-Environmental-Consultancy-Landing-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  